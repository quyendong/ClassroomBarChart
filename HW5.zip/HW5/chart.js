function readFileAsText()
{
    const fileToRead = document.getElementById("fileToRead").files[0];
    //const fileToRead = "./inputData.csv";
    const fileReader = new FileReader();
    fileReader.onload = function(e) 
    {
        fileContent = e.target.result;
        let stringdata = fileContent.toString();
        stringdata = stringdata.replace(/\n/g, ""); 
        var regex = /(HBG|\w{5}),(\w{9}),(\d{4}),(\w{2}|\w{3}),(\d+|\d+\w|\s+\d+|\s+\d+\w),(\w0(0|1|2|3|4|5|6|7|8|9)(0|1|2|3|4|5|6|7|8|9)),(\d|\w{3}),(\d),(\w* \w* \w* \w* \w*|\w* \w* \w* \w*|\w* \w* \w*|\w* \w*|\w*|),(\s+),(\s+|\d{2}:\d{2}\w{2}-\d{2}:\d{2}\w{2}|),(\s+\w\s+\w\s+\w\s+|\w\s+\w\s+\w\s+|\s+\w\s+\w\s+|\w\s+\w\s+|\s+\w\s+|\w\s+|\s+|),(\w{3}\s\d{3}|\s+|),("\w*,\w*"|"\w*,\w*\s\w*"|TBA)/g
        stringdata = stringdata.replace(/\r/g, "");
        const matches = stringdata.match(regex);
        let array = [];
        let values = [];
        let charthours = [];
        stringdata.replace(regex, function(match, campus, acadorg, classnbr, subject, catnbr, section, o, p, session, units, description, classtopic, time, days, facility, instructor){
            array.push({
                CAMPUS: campus,
                ACADORG: acadorg,
                CLASSNBR: classnbr,
                SUBJECT: subject,
                CATNBR: catnbr,
                SECTION: section,
                SESSION: session,
                UNITS: units,
                DESCRIPTION: description,
                CLASSTOPIC: classtopic,
                TIME: time,
                DAYS: days,
                FACILITY: facility,
                INSTRUCTOR: instructor,
            }); 
        });
        let newdata = [];
        for (i=0; i<array.length;i++)
        {
            newdata[i] = [];
            newdata[i].FACILITY = array[i].FACILITY;
            newdata[i].TIME = array[i].TIME;
            newdata[i].DAYS = array[i].DAYS;
        }
        let classarr = [];
        for (i=0; i<newdata.length;i++)
        {
            classarr[i] = newdata[i].FACILITY;
        }

        let uniqueCLASS = [];
        uniqueCLASS = classarr.filter(function(el, pos, arr){
            return classarr.indexOf(el) === pos;
        });

        let diffclassroom = {};
        for (key in uniqueCLASS)
        {
            diffclassroom[uniqueCLASS[key]]= {};
            diffclassroom[uniqueCLASS[key]]['TIME'] = [];
            diffclassroom[uniqueCLASS[key]]['DAYS'] = [];
         
            for(keys in newdata)
            {
                if(uniqueCLASS[key] === newdata[keys].FACILITY)
                {
                    diffclassroom[uniqueCLASS[key]]['TIME'].push(newdata[keys].TIME);
                    diffclassroom[uniqueCLASS[key]]['DAYS'].push(newdata[keys].DAYS);
                }
            }
        }

        //deletes the empty slots in the classrooms
        for (key in diffclassroom)
        {
             if (key === " ")
                delete diffclassroom[key];
        }
        //console.log(diffclassroom) //print out all classes, time, and day
        for (key in diffclassroom)
        {
            //delete undefined days
            for (keys in diffclassroom[key].DAYS[keys])
            {
                if (diffclassroom[key].DAYS[keys] === null)
                    delete (diffclassroom[key].DAYS[keys])
            }
        }

        let hours = []; //hours of each time period in each course by array number
        //calculate hours in each classroom per time period and stores into hours array above
        for (key in diffclassroom)
        {
            let temphours = 0;
            let HOURS = [];
            diffclassroom[key]['TIME'].forEach(function (element)
            {
                //console.log(element) //prints out time
                temphours = calctime(element);
               // console.log(temphours) //prints out how many hours
                HOURS.push(temphours);
            })
            hours.push(HOURS);
            //console.log(HOURS) //prints out how many hours per class period
        }
        //put days in an array
        days = [];
        for (key in diffclassroom)
        {
            let tempdays = "";
            let DAYS = [];
            diffclassroom[key]['DAYS'].forEach(function (element)
            {
                tempdays = element;
                DAYS.push(tempdays);
            })
            days.push(DAYS)
        }

        //console.log(days); //prints out 14 arrays, each element has another array containing days of classes
        
        let hoursPerDay = [];//contains total number of hours per days of the week per class
        //fx to get hoursPerDay
        for (key in days)
        {
            let blah = [];
            let M = 0;
            let T = 0;
            let W = 0;
            let R = 0;
            let F = 0;
            let random;
            for (keys in days[key])
            {
                if (random = days[key][keys].match("M"))
                    {
                        M = M + hours[key][keys]
                    }
                if (random = days[key][keys].match("T"))
                    {
                        T = T + hours[key][keys]
                    }
                if (random = days[key][keys].match("W"))
                    {
                        W = W + hours[key][keys]
                    }
                if (random = days[key][keys].match("R"))
                    {
                        R = R + hours[key][keys]
                    }
                if (random = days[key][keys].match("F"))
                    {
                        F = F + hours[key][keys]
                    }
            }
            blah.push(M)
            blah.push(T)
            blah.push(W)
            blah.push(R)
            blah.push(F)
            charthours.push(M)
            charthours.push(T)
            charthours.push(W)
            charthours.push(R)
            charthours.push(F)
        //    hoursPerDay.push(blah);
        }
        classrooms = [];  //store classroom names 

        for (key in diffclassroom)
        {
            classrooms.push(key);
        }

        console.log(classrooms)
        console.log(charthours)
        function calctime(string)
        {
            //console.log(string);
            let regex2 = /(\d{2}):(\d{2})(\w{2})/g
            let regex3 = /AM/g
            let regex4 = /PM/g
            let newArray = string.match(regex2);
            //console.log(newArray);
            let random = "";
            for (key in newArray)
            {
            if (random = newArray[key].match(regex3))
            {
            newArray[key] = newArray[key].replace("AM", "")
            var hours = newArray[key].match(/(\d+)/)[1];
            var minutes = newArray[key].match(/:(\d+)/)[1];
            var minutes = minutes.replace(":", "");
            hours = parseInt(hours);
            minutes = parseInt(minutes);
            minutes = minutes/60;
            hours = hours+minutes
            newArray[key] = hours;
            //console.log(newArray[key])
            }
            else if (random = newArray[key].match(regex4))
            {
            newArray[key] = newArray[key].replace("PM", "")
            var hours = newArray[key].match(/(\d+)/)[1];
            var minutes = newArray[key].match(/:(\d+)/)[1];
            var minutes = minutes.replace(":", "");
            hours = parseInt(hours);
            hours = hours+12
            minutes = parseInt(minutes);
            minutes = minutes/60;
            hours = hours+minutes
            newArray[key] = hours;
            //console.log(newArray[key])
            }
            }
            let result = newArray[1]-newArray[0];
            // console.log(result)
            return result;
        }
        //-----------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------
        //-----------------------------BEGIN CHART-------------------------------------------
        //-----------------------------------------------------------------------------------
        //-----------------------------------------------------------------------------------
        var canvas;
        var context;
        // Size of the histogram
        var width = 600, height=300;
        // The origin, bottom left corner, relative to the origin in the canvas
        var x = 50, y = 350; 

        // Data to be visualized
        let colors = ['#00ff99', '#ff99ff','#33ccff', '#ff9933', '#9966ff']
                        //light green, light pink, teal, light orange, purple
        //init function called by a body onload event.
        function init() 
        {
            canvas = document.getElementById('canvas'); 
            context = canvas.getContext('2d'); 
          
            // x, y is the bottom left position of the chart
            makeHistogram(x, y, width, height, charthours);   
        }

        // returns the max from the elements of the values array.
        function getMax(values) 
        {
            var maxValue = 0;
          
            for (i=0; i<values.length; i++) {
               if (maxValue < values[i])
                    maxValue = values[i];
            }
          return maxValue;
        }


        function drawAxis(width, height,  values, maxValue) 
        {
            // remember: we have the origin of the coordinate system at bottom left
            // Y values above will be negative
              
            context.strokeStyle = "black"; //We draw in black the outline.
            context.fillStyle = "black"; //We fill in black.
          
            //We define the vertical step unit. Is it 10 ? 20 ? 100 ? 1000 ? Depending on the
            // max unit value, we decide how the steps will be for the ticks
            var unit = 1; 
            /*  while (maxValue / (unit*10) > 1) 
                {
                    unit *= 10; 
                }*/
            
           //We define the highest vertical step.
            var yMaxOnAxis = parseInt(maxValue) / unit;   
          
            // Everything is in a path, all drawing orders will be drawn by a final call
            // to context.stroke() at the end of the function.
            context.beginPath(); //Begin a new path.
          
            // Draw the axis' lines
            context.moveTo(0, 0); //We place the cursor to origin.
            context.lineTo(0, -height); //We draw the vertical line. //draw the y axis of the graph
            context.moveTo(0, 0); //We place the cursor to origin.
            context.lineTo(width, 0); //We draw the horizontal line. //draw the x axis of the graph


            // ticks/labels on the vertical line
            context.textAlign = "left";

            for (i=0; i <= yMaxOnAxis; i++) {
                // move to the next graduation. the y value is negative due to
                // the change of the origin by a call to translate(x,y) in the drawHistogram
                // function.
                context.moveTo(0, -height / yMaxOnAxis * i );
              
                //draws the ticks on the vertical line of the graph
                //draw a horizontal line, 5 pixels long, on the left of the axis
                context.lineTo(-5, -height / yMaxOnAxis * i ); 
              
                // write the tick value, 25 pixels on the left of the vertical axis
                context.fillText(i*unit, -25, -height / yMaxOnAxis * i ); 
            }

            // Ticks/labels on the horizontal line
            var counter = 0; 
            // text centered below the tick
            context.textAlign = "center"; 

          
            // graduation on the horizontal line.
            var rectanglesWidth = width / classrooms.length;
            for (i=0; i <= values.length; i++) 
            {
                // Move to the next horizontal position of the tick
                context.moveTo(i*(width/values.length), 0); 
                 // draw a vertical line 5 pixels long: the tick
                if (Number.isInteger(i/5))
                    context.lineTo(i*(width/values.length), 10);
                else
                    context.lineTo(i*(width/values.length), 5);
                

                if (classrooms[i] === undefined)
                {

                }
                else
                {
                    // write tick label 15 pixels below the tick
                    //puts the text at the bottom
                    context.fillText(classrooms[i], i*rectanglesWidth, 20); 
                    counter++;
                }
 
            }
            // Draw everything in the path
            context.stroke(); 
            
        }

        // MakeHistogram building a bar plot. x, y is the bottom left position of the
        // histogram. Easier to reason with this coordonate system
        function makeHistogram(x, y, width, height, values) 
        {
            context.save();
            // Change the origin at bottom left. If we draw "above", Y values will be negative.
            // y=0 is the horizontal line at bottom
            context.translate(x, y);
            
            // Compute the max of the values array
            var maxValue = getMax(values);
          
            // step in pixels between two horizontal values for bar plot.
            var rectWidth = width / parseFloat(values.length); 

            // step in pixels between two vertical values for bar plot.
            var vStep = -height / parseFloat(maxValue); 
           
            //Set fill color to red and stroke color to black.
            context.fillStyle = "red"; 
            context.strokeStyle = "black";
         
            // Draw the histogram rectangles
            for(i=0; i < values.length; i++) 
            {       
                //We draw a filled red rectangle to represent the current value.
                context.fillStyle = colors[i%5]
                context.fillRect(i * rectWidth, 0, rectWidth, vStep * values[i]); 
              
               //We draw the outline of rectangle.
                context.strokeRect(i * rectWidth, 0, rectWidth, vStep * values[i]); 
            }
          
          // draw the axis
          drawAxis(width, height, values, maxValue); 
          context.restore();
        }
        init();
    }
    fileReader.readAsText(fileToRead, "UTF-8");
}